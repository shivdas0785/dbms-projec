<?php
		$conn = mysqli_connect("localhost", "root", "arti2810", "medical");
		if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
		}
?>